/**
 * CF Studio → DJ Mixer content script.
 * Runs on studio.creativefabrica.com/ai-music-generator/* track pages.
 * Waits for the page to render, scrapes track metadata from the DOM,
 * and injects a "Load in DJ Mixer" button.
 */

const MIXER_URL = 'http://localhost:4050' // TODO: swap for production URL before deploy

let mixerWindow = null // persistent reference to the open mixer tab

function scrapeTrackData() {
  const title = document.querySelector('h1')?.textContent?.trim() ?? null

  // Try multiple patterns — CF Studio uses /profiles/, /creator/, or /artist/
  const artistEl =
    document.querySelector('a[href*="/profiles/"]') ||
    document.querySelector('a[href*="/creator/"]') ||
    document.querySelector('a[href*="/artist/"]')
  const artist = artistEl?.textContent?.trim() ?? null
  const artistSlug = artistEl?.getAttribute('href') ?? null

  // Real track thumb — img with musicGenerator in src
  const thumbEl = document.querySelector('img[src*="musicGenerator"]')
  const thumb = thumbEl?.src ?? null

  // Audio element src
  const audioEl = document.querySelector('audio')
  const audioUrl = audioEl?.src ?? null

  const trackId = window.location.pathname.split('/').pop()

  return { title, artist, artistSlug, thumb, audioUrl, trackId }
}

function buildMixerUrl(data, deck = 'A') {
  const params = new URLSearchParams({
    deck,
    ...(data.title && { title: data.title }),
    ...(data.artist && { artist: data.artist }),
    ...(data.thumb && { thumb: data.thumb }),
    ...(data.audioUrl && { audioUrl: data.audioUrl }),
    ...(data.trackId && { trackId: data.trackId }),
  })
  return `${MIXER_URL}?load=${encodeURIComponent(params.toString())}`
}

function injectButton(data) {
  // Don't inject twice
  if (document.getElementById('cf-dj-mixer-btn')) return

  // Wrapper holds button + deck picker popup
  const wrapper = document.createElement('div')
  Object.assign(wrapper.style, {
    position: 'fixed',
    bottom: '24px',
    right: '24px',
    zIndex: '99999',
    fontFamily: 'system-ui, sans-serif',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-end',
    gap: '8px',
  })

  // Deck picker popup (hidden by default)
  const picker = document.createElement('div')
  picker.id = 'cf-dj-deck-picker'
  Object.assign(picker.style, {
    display: 'none',
    background: '#1e1b4b',
    border: '1px solid #7c3aed',
    borderRadius: '10px',
    padding: '10px 12px',
    boxShadow: '0 4px 20px rgba(124, 58, 237, 0.5)',
    color: '#fff',
    fontSize: '13px',
    fontWeight: '600',
    textAlign: 'center',
  })

  const label = document.createElement('div')
  label.textContent = 'Load into which deck?'
  Object.assign(label.style, { marginBottom: '8px', color: '#c4b5fd', fontSize: '12px' })
  picker.appendChild(label)

  const deckRow = document.createElement('div')
  Object.assign(deckRow.style, { display: 'flex', gap: '8px' })

  function makeDeckBtn(deck) {
    const db = document.createElement('button')
    db.textContent = `Deck ${deck}`
    Object.assign(db.style, {
      flex: '1',
      background: deck === 'A' ? '#7c3aed' : '#db2777',
      color: '#fff',
      border: 'none',
      borderRadius: '7px',
      padding: '7px 16px',
      fontSize: '13px',
      fontWeight: '700',
      cursor: 'pointer',
    })
    db.addEventListener('click', (e) => {
      e.stopPropagation()
      const fresh = scrapeTrackData()
      picker.style.display = 'none'

      if (mixerWindow && !mixerWindow.closed) {
        // Mixer already open — send track via postMessage, just focus it
        mixerWindow.focus()
        mixerWindow.postMessage({
          type: 'CF_LOAD_TRACK',
          deck,
          audioUrl: fresh.audioUrl,
          title: fresh.title,
          artist: fresh.artist,
          thumb: fresh.thumb,
          trackId: fresh.trackId,
        }, MIXER_URL)
      } else {
        // First open — use ?load= query params, store window ref
        mixerWindow = window.open(buildMixerUrl(fresh, deck), 'cf-dj-mixer')
      }
    })
    return db
  }

  deckRow.appendChild(makeDeckBtn('A'))
  deckRow.appendChild(makeDeckBtn('B'))
  picker.appendChild(deckRow)

  // Main button
  const btn = document.createElement('button')
  btn.id = 'cf-dj-mixer-btn'
  btn.textContent = '🎛 Load in DJ Mixer'
  btn.title = data.audioUrl
    ? `Load "${data.title}" into DJ Mixer`
    : 'Audio not found yet — try after pressing Play on the track'

  Object.assign(btn.style, {
    background: 'linear-gradient(135deg, #7c3aed, #db2777)',
    color: '#fff',
    border: 'none',
    borderRadius: '10px',
    padding: '10px 18px',
    fontSize: '14px',
    fontWeight: '600',
    cursor: 'pointer',
    boxShadow: '0 4px 20px rgba(124, 58, 237, 0.4)',
    transition: 'opacity 0.15s',
    lineHeight: '1.4',
  })

  btn.addEventListener('mouseenter', () => { btn.style.opacity = '0.85' })
  btn.addEventListener('mouseleave', () => { btn.style.opacity = '1' })

  btn.addEventListener('click', (e) => {
    e.stopPropagation()
    const fresh = scrapeTrackData()
    if (!fresh.audioUrl) {
      btn.textContent = '⚠️ Press Play on the track first, then try again'
      setTimeout(() => { btn.textContent = '🎛 Load in DJ Mixer' }, 3000)
      return
    }
    picker.style.display = picker.style.display === 'none' ? 'block' : 'none'
  })

  // Close picker when clicking outside
  document.addEventListener('click', () => { picker.style.display = 'none' })

  wrapper.appendChild(picker)
  wrapper.appendChild(btn)
  document.body.appendChild(wrapper)
}

// Page is CSR — wait for h1 to appear before scraping
function waitForContent(callback, timeout = 10000) {
  if (document.querySelector('h1')) {
    callback()
    return
  }

  const observer = new MutationObserver(() => {
    if (document.querySelector('h1')) {
      observer.disconnect()
      callback()
    }
  })

  observer.observe(document.body, { childList: true, subtree: true })

  // Timeout fallback
  setTimeout(() => {
    observer.disconnect()
    callback() // inject anyway with whatever data is available
  }, timeout)
}

// Only run on track detail pages (not the listing page)
const pathParts = window.location.pathname.split('/').filter(Boolean)
if (pathParts.length >= 2 && pathParts[0] === 'ai-music-generator') {
  waitForContent(() => {
    const data = scrapeTrackData()
    injectButton(data)
  })
}
